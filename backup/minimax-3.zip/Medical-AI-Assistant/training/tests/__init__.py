"""Training tests package."""

# Test configuration and utilities