-- Medical AI Assistant Demo Database Schema
-- HIPAA-compliant synthetic data structure

-- Users table with role-based access
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    role TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT 1,
    last_login TIMESTAMP,
    demo_session_id VARCHAR(100)
);

-- Patients table (synthetic data)
CREATE TABLE patients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    medical_record_number VARCHAR(50) UNIQUE NOT NULL,
    date_of_birth DATE NOT NULL,
    gender TEXT NOT NULL,
    blood_type TEXT,
    height_cm INTEGER,
    weight_kg REAL,
    emergency_contact_name VARCHAR(200),
    emergency_contact_phone VARCHAR(20),
    primary_physician_id INTEGER,
    insurance_provider VARCHAR(100),
    policy_number VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Medical conditions
CREATE TABLE medical_conditions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    condition_name VARCHAR(200) NOT NULL,
    icd10_code VARCHAR(10),
    diagnosed_date DATE,
    severity TEXT,
    status TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Vital signs records
CREATE TABLE vital_signs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    recorded_by INTEGER,
    blood_pressure_systolic INTEGER,
    blood_pressure_diastolic INTEGER,
    heart_rate INTEGER,
    temperature REAL,
    respiratory_rate INTEGER,
    oxygen_saturation INTEGER,
    glucose_level REAL,
    weight_kg REAL,
    bmi REAL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    source TEXT,
    notes TEXT
);

-- Medications
CREATE TABLE medications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    medication_name VARCHAR(200) NOT NULL,
    dosage VARCHAR(100),
    frequency VARCHAR(100),
    start_date DATE,
    end_date DATE,
    prescribed_by INTEGER,
    status TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Lab results
CREATE TABLE lab_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    test_name VARCHAR(200) NOT NULL,
    test_code VARCHAR(50),
    value REAL,
    unit VARCHAR(20),
    reference_range_min REAL,
    reference_range_max REAL,
    status TEXT,
    ordered_by INTEGER,
    collected_date DATE,
    reported_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- AI assessments and recommendations
CREATE TABLE ai_assessments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    assessment_type TEXT NOT NULL,
    assessment_data TEXT NOT NULL,
    confidence_score REAL,
    recommendations TEXT,
    created_by_user INTEGER,
    model_version VARCHAR(50),
    processing_time_ms INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Demo scenarios
CREATE TABLE demo_scenarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scenario_name VARCHAR(200) NOT NULL,
    scenario_type TEXT NOT NULL,
    description TEXT,
    patient_id INTEGER,
    workflow_steps TEXT,
    expected_outcomes TEXT,
    difficulty_level TEXT,
    estimated_duration_minutes INTEGER,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Demo sessions
CREATE TABLE demo_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    session_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    session_end TIMESTAMP,
    scenario_id INTEGER,
    interactions_count INTEGER DEFAULT 0,
    user_agent TEXT,
    ip_address VARCHAR(45),
    demo_data TEXT,
    feedback_score INTEGER,
    notes TEXT
);

-- Usage analytics
CREATE TABLE usage_analytics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER,
    user_id INTEGER,
    event_type VARCHAR(100) NOT NULL,
    event_data TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    component VARCHAR(100),
    response_time_ms INTEGER,
    success BOOLEAN
);

-- Demo configuration
CREATE TABLE demo_config (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    config_key VARCHAR(100) UNIQUE NOT NULL,
    config_value TEXT NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert demo configuration settings
INSERT INTO demo_config (config_key, config_value, description) VALUES
('demo_mode', '{"enabled": true, "version": "1.0", "features": ["synthetic_data", "demo_scenarios", "analytics"]}', 'Demo environment configuration'),
('performance_mode', '{"fast_responses": true, "preload_models": true, "cache_enabled": true}', 'Performance optimization settings'),
('analytics_enabled', '{"user_tracking": true, "performance_monitoring": true, "usage_stats": true}', 'Analytics configuration'),
('backup_settings', '{"auto_backup": true, "backup_interval_hours": 24, "retention_days": 30}', 'Backup and recovery settings');

-- Insert demo users
INSERT INTO users (email, password_hash, first_name, last_name, role, demo_session_id) VALUES
('admin@demo.medai.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewQn8YK7QdOKPH1S', 'Demo', 'Administrator', 'admin', 'DEMO_ADMIN_001'),
('nurse.jones@demo.medai.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewQn8YK7QdOKPH1S', 'Sarah', 'Jones', 'nurse', 'DEMO_NURSE_001'),
('patient.smith@demo.medai.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewQn8YK7QdOKPH1S', 'John', 'Smith', 'patient', 'DEMO_PATIENT_001'),
('nurse.brown@demo.medai.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewQn8YK7QdOKPH1S', 'Michael', 'Brown', 'nurse', 'DEMO_NURSE_002'),
('patient.davis@demo.medai.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewQn8YK7QdOKPH1S', 'Emily', 'Davis', 'patient', 'DEMO_PATIENT_002');

-- Create indexes for better performance
CREATE INDEX idx_patients_user_id ON patients(user_id);
CREATE INDEX idx_patients_mrn ON patients(medical_record_number);
CREATE INDEX idx_vital_signs_patient_id ON vital_signs(patient_id);
CREATE INDEX idx_vital_signs_date ON vital_signs(recorded_at);
CREATE INDEX idx_medical_conditions_patient_id ON medical_conditions(patient_id);
CREATE INDEX idx_medications_patient_id ON medications(patient_id);
CREATE INDEX idx_lab_results_patient_id ON lab_results(patient_id);
CREATE INDEX idx_ai_assessments_patient_id ON ai_assessments(patient_id);
CREATE INDEX idx_demo_sessions_user_id ON demo_sessions(user_id);
CREATE INDEX idx_usage_analytics_session_id ON usage_analytics(session_id);
CREATE INDEX idx_usage_analytics_timestamp ON usage_analytics(timestamp);