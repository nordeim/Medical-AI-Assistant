"""
API Routes Package

REST API endpoints for the application.
"""
